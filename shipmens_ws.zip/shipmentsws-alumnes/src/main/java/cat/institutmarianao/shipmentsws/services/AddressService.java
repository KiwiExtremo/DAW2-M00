package cat.institutmarianao.shipmentsws.services;
import java.util.List;

import cat.institutmarianao.shipmentsws.model.Address;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public interface AddressService {
	List<Address> findAll();
	
	Address getbyId(@Positive Long id);
	
	Address save(@NotNull @Valid Address address);
}
