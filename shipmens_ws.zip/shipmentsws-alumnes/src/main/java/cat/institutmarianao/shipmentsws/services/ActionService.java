package cat.institutmarianao.shipmentsws.services;

import java.util.List;

import cat.institutmarianao.shipmentsws.model.Action;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;

public interface ActionService {
	List<Action> findAll();

	Action getById(@Positive Long id);

	List<Action> findTrackingByTicketId(@Positive Long id);

	Action saveAction(@Valid Action action);
}
