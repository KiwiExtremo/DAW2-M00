package cat.institutmarianao.shipmentsws.validation.groups;

public interface OnCompanyCreate {

}
