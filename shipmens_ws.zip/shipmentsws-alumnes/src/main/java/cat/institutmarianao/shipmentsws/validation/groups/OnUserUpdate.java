package cat.institutmarianao.shipmentsws.validation.groups;

public interface OnUserUpdate {

}
