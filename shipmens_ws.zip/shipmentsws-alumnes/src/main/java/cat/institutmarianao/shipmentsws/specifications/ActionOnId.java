package cat.institutmarianao.shipmentsws.specifications;

import org.springframework.data.jpa.domain.Specification;

import cat.institutmarianao.shipmentsws.model.Action;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class ActionOnId implements Specification<Action> {

	private static final long serialVersionUID = 1L;
	private Long shipmentId;

	public ActionOnId(Long shipmentId) {
		this.shipmentId = shipmentId;
	}	
	
    @Override
    public Predicate toPredicate(Root<Action> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.equal(root.get("shipment").get("id"), shipmentId);
    }
}
