package cat.institutmarianao.shipmentsws.services.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import cat.institutmarianao.shipmentsws.exception.NotFoundException;
import cat.institutmarianao.shipmentsws.model.Address;
import cat.institutmarianao.shipmentsws.model.Shipment;
import cat.institutmarianao.shipmentsws.model.Shipment.Category;
import cat.institutmarianao.shipmentsws.model.Shipment.Status;
import cat.institutmarianao.shipmentsws.repositories.AddressRepository;
import cat.institutmarianao.shipmentsws.repositories.ShipmentRepository;
import cat.institutmarianao.shipmentsws.services.ActionService;
import cat.institutmarianao.shipmentsws.services.AddressService;
import cat.institutmarianao.shipmentsws.services.ShipmentService;
import cat.institutmarianao.shipmentsws.specifications.ShipmentReceivedBy;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithCategory;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithCourier;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithDate;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithStatus;
import cat.institutmarianao.shipmentsws.validation.groups.OnShipmentCreate;
import jakarta.validation.Valid;
import jakarta.validation.ValidationException;
import jakarta.validation.constraints.Positive;

@Validated
@Service
public class ShipmentServiceImpl implements ShipmentService {

	@Autowired
	private ShipmentRepository shipmentRepository;

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ActionService actionService;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private AddressService addressService;

	@Override
	public List<Shipment> findAll(Status status, String receivedBy, String courierAssigned, Category category,
			Date from, Date to) {
		Specification<Shipment> spec = Specification.where(new ShipmentWithStatus(status))
				.and(new ShipmentReceivedBy(receivedBy)).and(new ShipmentWithCourier(courierAssigned))
				.and(new ShipmentWithCategory(category)).and(new ShipmentWithDate(from, to));
		return shipmentRepository.findAll(spec);
	}

	@Override
	public Shipment getById(@Positive Long id) {
		return shipmentRepository.findById(id).orElseThrow(NotFoundException::new);
	}

	@Override
	public List<Shipment> findAllPending(String receivedBy, String courierAssigned, Category category, Date from,
			Date to) {
		Specification<Shipment> spec = Specification.where(new ShipmentWithStatus(Status.PENDING))
				.and(new ShipmentReceivedBy(receivedBy)).and(new ShipmentWithCourier(courierAssigned))
				.and(new ShipmentWithCategory(category)).and(new ShipmentWithDate(from, to));
		return shipmentRepository.findAll(spec);
	}

	@Override
	public List<Shipment> findAllInProcess(String receivedBy, String courierAssigned, Category category, Date from,
			Date to) {
		Specification<Shipment> spec = Specification.where(new ShipmentWithStatus(Status.IN_PROCESS))
				.and(new ShipmentReceivedBy(receivedBy)).and(new ShipmentWithCourier(courierAssigned))
				.and(new ShipmentWithCategory(category)).and(new ShipmentWithDate(from, to));
		return shipmentRepository.findAll(spec);
	}

	@Override
	public List<Shipment> findAllDelivered(String receivedBy, String courierAssigned, Category category, Date from,
			Date to) {
		Specification<Shipment> spec = Specification.where(new ShipmentWithStatus(Status.DELIVERED))
				.and(new ShipmentReceivedBy(receivedBy)).and(new ShipmentWithCourier(courierAssigned))
				.and(new ShipmentWithCategory(category)).and(new ShipmentWithDate(from, to));
		return shipmentRepository.findAll(spec);
	}

	@Override
	@Validated(OnShipmentCreate.class)
	public Shipment reception(@Valid Shipment shipment) {
		if (getById(shipment.getId()) != null)
			throw new ValidationException(messageSource.getMessage("error.Shipment.exists",
					new Object[] { shipment.getId() }, LocaleContextHolder.getLocale()));
		Address sender= addressRepository.findById(shipment.getSender().getId()).orElse(null);
		Address recipient= addressRepository.findById(shipment.getRecipient().getId()).orElse(null);
		if(sender==null) addressService.save(sender);
		if(recipient==null) addressService.save(recipient);
		actionService.saveAction(shipment.getTracking().get(0));
		return shipmentRepository.saveAndFlush(shipment);
	}

	@Override
	public void deleteById(@Positive Long shipmentId) {
		Shipment shipment = getById(shipmentId);
		if (shipment != null)
			shipmentRepository.deleteById(shipmentId);
	}
}
