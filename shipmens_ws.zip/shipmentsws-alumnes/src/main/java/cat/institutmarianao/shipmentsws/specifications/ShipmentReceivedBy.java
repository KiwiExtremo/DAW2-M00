package cat.institutmarianao.shipmentsws.specifications;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import cat.institutmarianao.shipmentsws.model.Action;
import cat.institutmarianao.shipmentsws.model.Action.Type;
import cat.institutmarianao.shipmentsws.model.Shipment;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class ShipmentReceivedBy implements Specification<Shipment> {

	private static final long serialVersionUID = 1L;
	private String receivedBy;
	private List<Predicate> predicates = new ArrayList<>();

    public ShipmentReceivedBy(String receivedBy) {
        this.receivedBy = receivedBy;
    }

    @Override
    public Predicate toPredicate(Root<Shipment> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        if (receivedBy == null) {
            return criteriaBuilder.isTrue(criteriaBuilder.literal(true)); // always true = no filtering
        }

        // Join con la tabla de acciones y usuarios
        Join<Shipment, Action> actionJoin = root.join("tracking", JoinType.INNER);

		predicates.add(criteriaBuilder.equal(actionJoin.get("type"), Type.valueOf(Action.RECEPTION)));
		predicates.add(criteriaBuilder.equal(actionJoin.get("performer").get("username"), receivedBy));

		return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	}
}

