package cat.institutmarianao.shipmentsws.services;

import java.util.List;

import cat.institutmarianao.shipmentsws.model.Office;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public interface OfficeService {
	List<Office> findAll();

	Office getById(@Positive Long id);

	Office save(@NotNull @Valid Office office);
}
