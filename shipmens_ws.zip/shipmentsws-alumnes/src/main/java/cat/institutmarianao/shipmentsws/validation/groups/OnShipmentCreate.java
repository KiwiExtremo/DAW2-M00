package cat.institutmarianao.shipmentsws.validation.groups;

public interface OnShipmentCreate {

}
