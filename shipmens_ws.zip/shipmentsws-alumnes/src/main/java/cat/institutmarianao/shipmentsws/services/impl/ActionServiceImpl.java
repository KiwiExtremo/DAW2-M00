package cat.institutmarianao.shipmentsws.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import cat.institutmarianao.shipmentsws.exception.NotFoundException;
import cat.institutmarianao.shipmentsws.model.Action;
import cat.institutmarianao.shipmentsws.model.Action.Type;
import cat.institutmarianao.shipmentsws.repositories.ActionRepository;
import cat.institutmarianao.shipmentsws.services.ActionService;
import cat.institutmarianao.shipmentsws.specifications.ActionOnId;
import cat.institutmarianao.shipmentsws.validation.groups.OnActionCreate;
import jakarta.validation.Valid;
import jakarta.validation.ValidationException;
import jakarta.validation.constraints.Positive;

@Validated
@Service
public class ActionServiceImpl implements ActionService {

	@Autowired
	private ActionRepository actionRepository;

	@Autowired
	private MessageSource messageSource;

	@Override
	public List<Action> findAll() {
		return actionRepository.findAll();
	}

	@Override
	public Action getById(@Positive Long id) {
		return actionRepository.findById(id).orElseThrow(NotFoundException::new);
	}

	@Override
	public List<Action> findTrackingByTicketId(@Positive Long id) {
		Specification<Action> actionsSpec = Specification.where(new ActionOnId(id));
		return actionRepository.findAll(actionsSpec);
	}

	@Override
	@Validated(OnActionCreate.class)
	public Action saveAction(@Valid Action action) {
		List<Action> tracking = findTrackingByTicketId(action.getShipment().getId());
		if(action.getType().equals(Type.RECEPTION)) {
			if (!tracking.stream().anyMatch(t -> t.getType().equals(Type.RECEPTION))) {
				return actionRepository.saveAndFlush(action);
			}
		}else if (!action.getType().equals(Type.RECEPTION)) {
			if (tracking.stream().anyMatch(t -> t.getType().equals(Type.ASSIGNMENT))) {
				if (!action.getType().equals(Type.ASSIGNMENT) && tracking.size() < 3) {
					tracking.add(action);
					return actionRepository.saveAndFlush(action);
				}
			} else if (tracking.size() < 3) {
				if (action.getType().equals(Type.ASSIGNMENT)) {
					tracking.add(action);
					return actionRepository.saveAndFlush(action);
				}
			} else
				throw new ValidationException(messageSource.getMessage("error.Tracking.is.full", null,
						LocaleContextHolder.getLocale()));
		} else
			throw new ValidationException(messageSource.getMessage("error.Tracking.double.reception", null,
					LocaleContextHolder.getLocale()));
		return null;

	}
}
