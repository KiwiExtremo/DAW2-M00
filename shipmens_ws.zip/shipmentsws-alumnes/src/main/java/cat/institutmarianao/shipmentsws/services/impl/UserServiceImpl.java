package cat.institutmarianao.shipmentsws.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import cat.institutmarianao.shipmentsws.exception.NotFoundException;
import cat.institutmarianao.shipmentsws.model.Company;
import cat.institutmarianao.shipmentsws.model.Courier;
import cat.institutmarianao.shipmentsws.model.Office;
import cat.institutmarianao.shipmentsws.model.Receptionist;
import cat.institutmarianao.shipmentsws.model.User;
import cat.institutmarianao.shipmentsws.model.User.Role;
import cat.institutmarianao.shipmentsws.repositories.CompanyRepository;
import cat.institutmarianao.shipmentsws.repositories.OfficeRepository;
import cat.institutmarianao.shipmentsws.repositories.UserRepository;
import cat.institutmarianao.shipmentsws.services.CompanyService;
import cat.institutmarianao.shipmentsws.services.OfficeService;
import cat.institutmarianao.shipmentsws.services.UserService;
import cat.institutmarianao.shipmentsws.specifications.UserWithFullName;
import cat.institutmarianao.shipmentsws.specifications.UserWithRole;
import cat.institutmarianao.shipmentsws.validation.groups.OnUserCreate;
import cat.institutmarianao.shipmentsws.validation.groups.OnUserUpdate;
import jakarta.validation.Valid;
import jakarta.validation.ValidationException;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/

@Validated
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private OfficeRepository officeRepository;
	
	@Autowired
	private OfficeService officeService;

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private CompanyService companyService;

	@Override
	public User authenticate(@NotEmpty String username, @NotEmpty String password) {
		User user = getByUsername(username);

		/*
		 * Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
		 * logger.info("PWD"+password); logger.info("BDPWD"+user.getPassword());
		 */

		if (!passwordEncoder.matches(password, user.getPassword()))
			throw new ValidationException(messageSource.getMessage("error.UserService.user.password",
					new Object[] { username }, LocaleContextHolder.getLocale()));

		return user;
	}

	@Override
	public List<User> findAll(Role[] roles, String fullName) {
		Specification<User> spec = Specification.where(new UserWithRole(roles)).and(new UserWithFullName(fullName));
		return userRepository.findAll(spec);
	}

	@Override
	public User getByUsername(@NotBlank String username) {
		/*
		 * User user= userRepository.findById(username).orElse(null); if(user==null)
		 * throw new ValidationException(messageSource.getMessage(
		 * "error.UserService.user.not.found", new Object[] { username },
		 * LocaleContextHolder.getLocale()));
		 */

		return userRepository.findById(username).orElseThrow(NotFoundException::new);
	}

	@Override
	@Validated(OnUserCreate.class)
	public User save(@NotNull @Valid User user) {
		/*if (!Role.LOGISTICS_MANAGER.equals(performer.getRole())) { String
		 errorMerrage = messageSource.getMessage("error.Performer.is.not.valid", null,
		 LocaleContextHolder.getLocale()); throw new ValidationException
		 (errorMerrage); } */
		
		if (user instanceof Receptionist receptionist) {
			if (receptionist.getOffice() != null) {
				Office office = officeRepository.findById(receptionist.getOffice().getId()).orElse(null);
				if (office == null) {
					officeService.save(receptionist.getOffice());
				}
			}
		} else if (user instanceof Courier courier) {
			if (courier.getCompany() != null) {
				Company company = companyRepository.findById(courier.getCompany().getId()).orElse(null);
				if (company == null) {
					companyService.save(courier.getCompany());
				}
			}
		}
		if (getByUsername(user.getUsername()) != null)
			throw new ValidationException(messageSource.getMessage("error.UserService.user.found",
					new Object[] { user.getUsername() }, LocaleContextHolder.getLocale()));
		/*if (!Role.LOGISTICS_MANAGER.equals(performer.getRole())) {
			String errorMerrage = messageSource.getMessage("error.Performer.is.not.valid", null, LocaleContextHolder.getLocale());
			throw new ValidationException (errorMerrage);
		}*/
		User ret = userRepository.saveAndFlush(user);
		return ret;
	}

	@Override
	@Validated(OnUserUpdate.class)
	public User update(@NotNull @Valid User user) {
		User dbUser = getByUsername(user.getUsername());

		if (user.getPassword() != null) {
			dbUser.setPassword(user.getPassword());
		}
		if (user.getFullName() != null) {
			dbUser.setFullName(user.getFullName());
		}
		if (user.getExtension() != null) {
			dbUser.setExtension(user.getExtension());
		}

		if (user instanceof Receptionist receptionist && dbUser instanceof Receptionist dbReceptionist) {

			if (receptionist.getOffice() != null) {
				dbReceptionist.setOffice(receptionist.getOffice());
			}
			if (receptionist.getPlace() != null) {
				dbReceptionist.setPlace(receptionist.getPlace());
			}
		} else if (user instanceof Courier courier && dbUser instanceof Courier dbCourier) {
			if (courier.getCompany() != null) {
				dbCourier.setCompany(courier.getCompany());
			}
		}

		return userRepository.saveAndFlush(dbUser);
	}

	@Override
	public void deleteByUsername(@NotBlank String username) {
		User user = getByUsername(username);
		if (user != null)
			userRepository.deleteById(username);
	}
}
