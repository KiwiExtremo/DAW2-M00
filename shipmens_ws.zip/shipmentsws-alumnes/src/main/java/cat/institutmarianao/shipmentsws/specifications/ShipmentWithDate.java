package cat.institutmarianao.shipmentsws.specifications;

import java.util.Date;

import org.springframework.data.jpa.domain.Specification;

import cat.institutmarianao.shipmentsws.model.Action;
import cat.institutmarianao.shipmentsws.model.Shipment;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class ShipmentWithDate implements Specification<Shipment> {
	private static final long serialVersionUID = 1L;
	private Date from;
	private Date to;

	public ShipmentWithDate(Date from, Date to) {
		this.from = from;
		this.to = to;
	}

	@Override
	public Predicate toPredicate(Root<Shipment> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
		if (from == null && to == null) {
			return criteriaBuilder.isTrue(criteriaBuilder.literal(true));
		} else {
			Join<Shipment, Action> actionJoin = root.join("tracking", JoinType.INNER);
			if (from != null) {
				return criteriaBuilder.greaterThanOrEqualTo(actionJoin.get("date"), from);
			} else if (to != null) {
				return criteriaBuilder.lessThanOrEqualTo(actionJoin.get("date"), to);
			} else {
				return criteriaBuilder.between(actionJoin.get("date"), from, to);
			}
		}
	}

}
