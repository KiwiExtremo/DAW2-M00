package cat.institutmarianao.shipmentsws.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import cat.institutmarianao.shipmentsws.exception.NotFoundException;
import cat.institutmarianao.shipmentsws.model.Office;
import cat.institutmarianao.shipmentsws.repositories.OfficeRepository;
import cat.institutmarianao.shipmentsws.services.OfficeService;
import cat.institutmarianao.shipmentsws.validation.groups.OnOfficeCreate;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Validated
@Service
public class OfficeServiceImpl implements OfficeService {

	@Autowired
	private OfficeRepository officeRepository;

	@Override
	public List<Office> findAll() {
		return officeRepository.findAll();
	}

	@Override
	public Office getById(@Positive Long id) {
		/*
		 * Office office= officeRepository.findById(id).orElse(null); if(office==null)
		 * throw new ValidationException(messageSource.getMessage(
		 * "error.OfficeService.office.not.found", new Object[] { id },
		 * LocaleContextHolder.getLocale()));
		 */
		return officeRepository.findById(id).orElseThrow(NotFoundException::new);
	}

	@Override
	@Validated(OnOfficeCreate.class)
	public Office save(@NotNull @Valid Office office) {
		return officeRepository.saveAndFlush(office);
	}
}
